--==================================================================
-- HeRo Shield — FiveM anticheat config
-- Set the three values at the top, then tune the detections below.
--==================================================================
Config = {}

-- Your deployed dashboard URL (no trailing slash)
Config.SiteUrl     = 'https://hero-shield.onrender.com'

-- Must match the INGEST_TOKEN you set on the site (Render -> Environment)
Config.IngestToken = 'change-me-ingest-token'

-- The server name as it should appear on the dashboard
Config.ServerName  = 'My FiveM Server'

Config.Debug        = false   -- print HTTP results to the server console
Config.HeartbeatSec = 30      -- how often to tell the dashboard the server is alive
Config.PlaytimeSec  = 60      -- how often to push each player's +playtime

--------------------------------------------------------------------
-- Detections.  action = 'ban' | 'kick' | 'log' | 'off'
-- Thresholds are deliberately forgiving to avoid false positives;
-- raise/lower them to fit your server.
--------------------------------------------------------------------
Config.Detections = {
  -- server-authoritative (hard to fake)
  HealthHack       = { action = 'ban',  overMax = 5 },      -- hp above the ped's max
  ArmorHack        = { action = 'ban',  max = 100 },        -- armor above 100
  SpeedHack        = { action = 'kick', maxSpeed = 14.0 },  -- m/s on foot (~50 km/h)
  TeleportWaypoint = { action = 'ban',  jump = 300.0 },     -- meters moved in one tick, on foot
  BlacklistedWeapon= { action = 'ban',  weapons = {
                         `WEAPON_RPG`, `WEAPON_GRENADELAUNCHER`, `WEAPON_MINIGUN`,
                         `WEAPON_RAILGUN`, `WEAPON_HOMINGLAUNCHER`, `WEAPON_COMPACTLAUNCHER`,
                       } },

  -- client-reported (corroborated + rate-limited on the server)
  GodMode          = { action = 'ban' },
  Invisible        = { action = 'kick', seconds = 10 },
  NoClip           = { action = 'ban' },
  VehicleNoClip    = { action = 'ban' },
  SuperJump        = { action = 'kick', maxJump = 3.5 },    -- meters of upward velocity
  ShrinkPed        = { action = 'ban' },
  ChangePed        = { action = 'log' },
  Spectate         = { action = 'ban' },
  FreeCam          = { action = 'kick', maxDist = 120.0 },  -- camera distance from ped
  VehicleBoost     = { action = 'kick', maxSpeed = 90.0 },  -- m/s in a vehicle (~324 km/h)
  InfiniteStamina  = { action = 'log' },
  DamageModifier   = { action = 'ban' },
  SuperPunch       = { action = 'ban' },
}

-- Weapons allowed to deal high damage without flagging DamageModifier (optional)
Config.HeavyWeapons = {
  `WEAPON_SNIPERRIFLE`, `WEAPON_HEAVYSNIPER`, `WEAPON_MARKSMANRIFLE`,
}
