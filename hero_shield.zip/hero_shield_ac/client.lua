--==================================================================
-- HeRo Shield — FiveM anticheat (client)
-- Watches things only visible on the player's machine and reports
-- them to the server, which decides ban/kick/log. Checks are
-- conservative (need several consecutive ticks) to avoid false hits.
--==================================================================
local function cfg(k) return Config.Detections[k] end
local function on(k) local d = cfg(k); return d and d.action ~= 'off' end

-- client-side throttle so we don't spam the server
local last = {}
local function flag(key, info)
  if not on(key) then return end
  local now = GetGameTimer()
  if last[key] and now - last[key] < 8000 then return end
  last[key] = now
  TriggerServerEvent('hero_shield_ac:flag', key, info or '')
end

-- small animal ped list for "turned into an animal" (log only)
local ANIMALS = {
  [`a_c_chop`]=1,[`a_c_cat_01`]=1,[`a_c_deer`]=1,[`a_c_rottweiler`]=1,
  [`a_c_cow`]=1,[`a_c_pig`]=1,[`a_c_chickenhawk`]=1,[`a_c_boar`]=1,
  [`a_c_coyote`]=1,[`a_c_mtlion`]=1,[`a_c_rabbit_01`]=1,[`a_c_rat`]=1,
}

-- counters for "sustained" conditions
local noclipTicks, vehNoclipTicks, invisTicks, sprintStart = 0, 0, 0, 0

CreateThread(function()
  while true do
    Wait(500)
    local ped = PlayerPedId()
    if ped and ped ~= 0 and not IsEntityDead(ped) then
      local inVeh = IsPedInAnyVehicle(ped, false)

      -- SuperJump: large upward velocity while on foot
      if on('SuperJump') and not inVeh then
        local v = GetEntityVelocity(ped)
        local maxJ = cfg('SuperJump').maxJump or 3.5
        if v.z > maxJ + 3.0 then flag('SuperJump', ('vz %.1f'):format(v.z)) end
      end

      -- Invisible: local ped invisible for several ticks
      if on('Invisible') then
        if not IsEntityVisible(ped) then
          invisTicks = invisTicks + 1
          local need = math.floor(((cfg('Invisible').seconds or 10) * 1000) / 500)
          if invisTicks >= need then flag('Invisible', ('invisible ~%ds'):format(cfg('Invisible').seconds or 10)) end
        else
          invisTicks = 0
        end
      end

      -- Spectate: spectator mode without being allowed
      if on('Spectate') and NetworkIsInSpectatorMode() then
        flag('Spectate', 'spectator mode on')
      end

      -- FreeCam: gameplay camera far from the ped
      if on('FreeCam') then
        local cam = GetGameplayCamCoord()
        local pos = GetEntityCoords(ped)
        local d = #(cam - pos)
        local maxD = cfg('FreeCam').maxDist or 120.0
        if d > maxD then flag('FreeCam', ('cam %.0f m away'):format(d)) end
      end

      -- ChangePed: player model is an animal (log only on most servers)
      if on('ChangePed') then
        if ANIMALS[GetEntityModel(ped)] then flag('ChangePed', 'animal ped') end
      end

      -- InfiniteStamina: sprinting continuously for a long time
      if on('InfiniteStamina') then
        if IsPedSprinting(ped) then
          if sprintStart == 0 then sprintStart = GetGameTimer() end
          if GetGameTimer() - sprintStart > 60000 then flag('InfiniteStamina', 'sprint > 60s') end
        else
          sprintStart = 0
        end
      end

      -- NoClip (on foot): in the air, moving under control, not falling/parachuting/ragdolling
      if on('NoClip') and not inVeh then
        local inAir   = IsPedInParachuteFreeFall(ped) == false and IsEntityInAir(ped)
        local falling = IsPedFalling(ped)
        local ragdoll = IsPedRagdoll(ped)
        local moving  = #(GetEntityVelocity(ped)) > 1.0
        local height  = GetEntityHeightAboveGround(ped)
        if inAir and moving and not falling and not ragdoll and height > 3.0 then
          noclipTicks = noclipTicks + 1
          if noclipTicks >= 6 then flag('NoClip', ('airborne control %.0fm'):format(height)) end
        else
          noclipTicks = 0
        end
      end

      -- VehicleNoClip: vehicle sustained high in the air while driven (not a normal stunt)
      if on('VehicleNoClip') and inVeh then
        local veh = GetVehiclePedIsIn(ped, false)
        local height = GetEntityHeightAboveGround(veh)
        local moving = #(GetEntityVelocity(veh)) > 2.0
        if height > 8.0 and moving and not IsEntityInAir(veh) then
          -- height > 8 but engine says "not in air" => clipping through geometry
          vehNoclipTicks = vehNoclipTicks + 1
          if vehNoclipTicks >= 6 then flag('VehicleNoClip', ('veh clipping %.0fm'):format(height)) end
        else
          vehNoclipTicks = 0
        end
      end
    end
  end
end)
