fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'hero_shield_ac'
description 'HeRo Shield — FiveM anticheat (reports to the HeRo Shield dashboard)'
author 'HeRo Shield'
version '1.0.0'

shared_script 'config.lua'
client_script 'client.lua'
server_script 'server.lua'
