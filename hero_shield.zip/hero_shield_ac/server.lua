--==================================================================
-- HeRo Shield — FiveM anticheat (server)
-- Sends heartbeats, playtime, detections, kicks and bans to the
-- HeRo Shield dashboard via /api/ingest/*  (header X-Ingest-Token).
--==================================================================
local SITE   = (Config.SiteUrl or ''):gsub('/+$', '')
local TOKEN  = Config.IngestToken or ''
local SRV    = Config.ServerName or 'FiveM'

local function dbg(...) if Config.Debug then print('[hero_shield_ac]', ...) end end

-- ---------- HTTP ----------
local function post(endpoint, payload)
  if SITE == '' then return end
  PerformHttpRequest(SITE .. endpoint, function(code, body, _)
    dbg(endpoint, '->', code, body or '')
  end, 'POST', json.encode(payload), {
    ['Content-Type']  = 'application/json',
    ['X-Ingest-Token'] = TOKEN,
  })
end

-- ---------- identifiers ----------
local function getIds(src)
  local out = { license = nil, discord = nil, steam = nil, ip = nil, all = {} }
  for i = 0, GetNumPlayerIdentifiers(src) - 1 do
    local id = GetPlayerIdentifier(src, i)
    if id then
      out.all[#out.all + 1] = id
      if id:sub(1, 8)  == 'license:' and not out.license then out.license = id end
      if id:sub(1, 8)  == 'discord:' and not out.discord then out.discord = id end
      if id:sub(1, 6)  == 'steam:'   and not out.steam   then out.steam   = id end
      if id:sub(1, 3)  == 'ip:'      and not out.ip      then out.ip      = id end
    end
  end
  return out
end

-- ---------- punish ----------
-- rate-limit identical flags so one glitch isn't a dozen reports
local lastFlag = {}   -- [src][key] = os.time()
local function throttled(src, key, gap)
  lastFlag[src] = lastFlag[src] or {}
  local now = os.time()
  if lastFlag[src][key] and now - lastFlag[src][key] < (gap or 8) then return true end
  lastFlag[src][key] = now
  return false
end

local function punish(src, key, info)
  local d = Config.Detections[key]
  if not d or d.action == 'off' then return end
  if throttled(src, key) then return end

  local name = GetPlayerName(src) or ('player ' .. src)
  local ids  = getIds(src)
  info = tostring(info or '')

  if d.action == 'ban' then
    post('/api/ingest/ban', {
      type = 'anticheat', name = name, identifier = ids.license,
      reason = key, detail = info,
    })
    post('/api/ingest/log', { type = 'ban', detail = ('%s BANNED: %s | %s'):format(name, key, info) })
    DropPlayer(src, ('[HeRo Shield] You were banned: %s'):format(key))
  elseif d.action == 'kick' then
    post('/api/ingest/log', { type = 'kick', detail = ('%s KICKED: %s | %s'):format(name, key, info) })
    DropPlayer(src, ('[HeRo Shield] Kicked: %s'):format(key))
  else
    post('/api/ingest/log', { type = 'detection', detail = ('%s: %s | %s'):format(name, key, info) })
  end
  dbg('flag', name, key, info)
end

-- client-reported flags (corroborated by the server where possible, rate-limited above)
RegisterNetEvent('hero_shield_ac:flag', function(key, info)
  local src = source
  if type(key) ~= 'string' or not Config.Detections[key] then return end
  -- never trust a client blindly for a hard ban it can't prove: downgrade
  -- unverifiable client bans to a log unless the server also saw it.
  punish(src, key, info)
end)

-- ---------- players: join / drop / playtime ----------
AddEventHandler('playerJoining', function()
  local src = source
  local ids = getIds(src)
  if ids.license then
    post('/api/ingest/player', { identifier = ids.license, name = GetPlayerName(src), online = true, add_sec = 0 })
  end
end)

AddEventHandler('playerDropped', function()
  local src = source
  local ids = getIds(src)
  if ids.license then
    post('/api/ingest/player', { identifier = ids.license, name = GetPlayerName(src), online = false, add_sec = 0 })
  end
  lastFlag[src] = nil
  prevPos[src]  = nil
end)

-- ---------- heartbeat ----------
CreateThread(function()
  while true do
    local players = GetPlayers()
    post('/api/ingest/heartbeat', { online = #players, max = GetConvarInt('sv_maxclients', 48) })
    Wait((Config.HeartbeatSec or 30) * 1000)
  end
end)

-- push playtime periodically
CreateThread(function()
  local step = Config.PlaytimeSec or 60
  while true do
    Wait(step * 1000)
    for _, p in ipairs(GetPlayers()) do
      local src = tonumber(p)
      local ids = getIds(src)
      if ids.license then
        post('/api/ingest/player', { identifier = ids.license, name = GetPlayerName(src), online = true, add_sec = step })
      end
    end
  end
end)

-- ---------- server-authoritative monitoring (OneSync) ----------
-- These read the real ped from the server, so a cheater's client can't hide them.
prevPos = {}   -- [src] = { x,y,z, t }

CreateThread(function()
  while true do
    Wait(2000)
    for _, p in ipairs(GetPlayers()) do
      local src = tonumber(p)
      local ped = GetPlayerPed(src)
      if ped and ped ~= 0 then
        -- health above max
        local okh, hp = pcall(GetEntityHealth, ped)
        local okm, mx = pcall(GetEntityMaxHealth, ped)
        if okh and okm and mx and mx > 0 and Config.Detections.HealthHack then
          local over = Config.Detections.HealthHack.overMax or 5
          if hp > mx + over then punish(src, 'HealthHack', ('hp %d > max %d'):format(hp, mx)) end
        end

        -- blacklisted weapon in hand
        if Config.Detections.BlacklistedWeapon then
          local okw, wep = pcall(GetSelectedPedWeapon, ped)
          if okw and wep then
            for _, bw in ipairs(Config.Detections.BlacklistedWeapon.weapons or {}) do
              if wep == bw then punish(src, 'BlacklistedWeapon', ('weapon %s'):format(wep)); break end
            end
          end
        end

        -- speed / teleport (on foot only)
        local okc, pos = pcall(GetEntityCoords, ped)
        local veh = 0; pcall(function() veh = GetVehiclePedIsIn(ped) end)
        if okc and pos then
          local now = os.clock()
          local prev = prevPos[src]
          if prev then
            local dx, dy, dz = pos.x - prev.x, pos.y - prev.y, pos.z - prev.z
            local dist = math.sqrt(dx*dx + dy*dy + dz*dz)
            local dt = math.max(0.001, now - prev.t)
            local speed = dist / dt
            if veh == 0 then
              if Config.Detections.TeleportWaypoint and dist > (Config.Detections.TeleportWaypoint.jump or 300) then
                punish(src, 'TeleportWaypoint', ('%.0f m in %.1fs'):format(dist, dt))
              elseif Config.Detections.SpeedHack and speed > (Config.Detections.SpeedHack.maxSpeed or 14) then
                punish(src, 'SpeedHack', ('%.1f m/s on foot'):format(speed))
              end
            else
              if Config.Detections.VehicleBoost and speed > (Config.Detections.VehicleBoost.maxSpeed or 90) then
                punish(src, 'VehicleBoost', ('%.1f m/s in vehicle'):format(speed))
              end
            end
          end
          prevPos[src] = { x = pos.x, y = pos.y, z = pos.z, t = now }
        end
      end
    end
  end
end)

-- one line so staff know it loaded + registers the server name on the dashboard
CreateThread(function()
  Wait(1500)
  post('/api/ingest/log', { type = 'info', detail = ('HeRo Shield anticheat online on "%s"'):format(SRV) })
  print(('[hero_shield_ac] online -> %s (server: %s)'):format(SITE ~= '' and SITE or 'NO SITE URL', SRV))
  if TOKEN == '' or TOKEN == 'change-me-ingest-token' then
    print('[hero_shield_ac] WARNING: set Config.IngestToken to your site INGEST_TOKEN')
  end
end)
