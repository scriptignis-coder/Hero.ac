# HeRo Shield — FiveM anticheat (`hero_shield_ac`)

In-game anticheat resource that watches players and reports detections,
kicks and bans to your HeRo Shield dashboard.

This is the **live anticheat**, separate from the **screenshare scanner .exe**.
Both feed the same dashboard.

## Install

1. Copy the `hero_shield_ac` folder into your server's `resources/` folder.
2. Open `config.lua` and set:
   - `Config.SiteUrl` = your dashboard URL (e.g. `https://hero-shield.onrender.com`)
   - `Config.IngestToken` = the **same** value as `INGEST_TOKEN` on your site (Render → Environment)
   - `Config.ServerName` = how the server should show on the dashboard
3. In `server.cfg` add: `ensure hero_shield_ac`
4. **OneSync must be ON** (`set onesync on`) — the server-side checks need it.

## What it detects

**Server-authoritative** (the cheater's client can't hide these):
- HealthHack (hp above max), SpeedHack (on foot), TeleportWaypoint,
  VehicleBoost, BlacklistedWeapon.

**Client-reported** (corroborated + rate-limited on the server):
- GodMode, Invisible, NoClip, VehicleNoClip, SuperJump, Spectate,
  FreeCam, InfiniteStamina, ChangePed.

Each detection's action is set per-entry in `config.lua`: `ban` / `kick` / `log` / `off`.

## How it reports

`PerformHttpRequest` → `Config.SiteUrl` with header `X-Ingest-Token`:
- `POST /api/ingest/heartbeat`  — server alive + player count (every 30s)
- `POST /api/ingest/player`     — join / leave / playtime
- `POST /api/ingest/log`        — detections and kicks
- `POST /api/ingest/ban`        — bans (player is also dropped in-game)

## Tuning / false positives

Thresholds in `config.lua` are deliberately forgiving. If a legit stunt map
or script trips something, set that detection to `log` first, watch the
dashboard, then raise its threshold or turn it `off`. Start with
`Config.Debug = true` to see HTTP results in the server console.

## Notes

- Client checks are a safety net; the reliable ones run on the server.
- No cheat names or cheat code are hardcoded — it detects *behaviour*
  (health over max, impossible speed, forbidden weapon), not tools.
